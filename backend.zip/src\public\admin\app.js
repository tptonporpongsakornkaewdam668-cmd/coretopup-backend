/* ─────────────────────────────────────────────────────────────────────────────
   GameTopUp — Admin Panel JavaScript
   ทุก API call ใช้ Admin JWT ที่ login จาก /api/admin/login
───────────────────────────────────────────────────────────────────────────── */
const API = "http://localhost:5000/api";

// ══════════════════════════════════════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════════════════════════════════════
let adminToken = sessionStorage.getItem("adminToken") || null;
let allOrders = [];
let allUsers = [];

// ══════════════════════════════════════════════════════════════════════════════
//  HELPERS
// ══════════════════════════════════════════════════════════════════════════════
const $ = (id) => document.getElementById(id);

function showToast(msg, type = "success") {
    const t = $("toast");
    t.textContent = (type === "success" ? "✅ " : "❌ ") + msg;
    t.className = `toast ${type}`;
    t.classList.remove("hidden");
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.add("hidden"), 3200);
}

function formatDate(iso) {
    if (!iso) return "-";
    return new Date(iso).toLocaleString("th-TH", {
        year: "numeric", month: "short", day: "numeric",
        hour: "2-digit", minute: "2-digit",
    });
}

function statusBadge(s) {
    const icons = { pending: "⏳", processing: "🔄", completed: "✅", failed: "❌" };
    return `<span class="badge ${s}">${icons[s] || ""} ${s}</span>`;
}

async function apiFetch(path, opts = {}) {
    const headers = { "Content-Type": "application/json" };
    if (adminToken) headers["Authorization"] = "Bearer " + adminToken;
    const res = await fetch(API + path, { ...opts, headers });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "API Error");
    return data;
}

// ══════════════════════════════════════════════════════════════════════════════
//  LOGIN / LOGOUT
// ══════════════════════════════════════════════════════════════════════════════
$("login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("login-btn");
    const err = $("login-error");
    err.classList.add("hidden");
    btn.textContent = "กำลังเข้าสู่ระบบ...";
    btn.disabled = true;

    try {
        const data = await apiFetch("/admin/login", {
            method: "POST",
            body: JSON.stringify({
                email: $("login-email").value,
                password: $("login-password").value,
            }),
        });

        adminToken = data.token;
        sessionStorage.setItem("adminToken", adminToken);
        $("admin-name-sidebar").textContent = data.admin.email.split("@")[0];

        $("login-screen").classList.add("hidden");
        $("app").classList.remove("hidden");
        loadDashboard();
    } catch (ex) {
        err.textContent = ex.message;
        err.classList.remove("hidden");
    } finally {
        btn.textContent = "เข้าสู่ระบบ";
        btn.disabled = false;
    }
});

$("logout-btn").addEventListener("click", () => {
    adminToken = null;
    sessionStorage.removeItem("adminToken");
    $("app").classList.add("hidden");
    $("login-screen").classList.remove("hidden");
    $("login-password").value = "";
});

// ══════════════════════════════════════════════════════════════════════════════
//  AUTO-LOGIN (ถ้ามี token ใน sessionStorage)
// ══════════════════════════════════════════════════════════════════════════════
async function tryAutoLogin() {
    if (!adminToken) return;
    try {
        const data = await apiFetch("/admin/verify");
        $("admin-name-sidebar").textContent = data.admin.email.split("@")[0];
        $("login-screen").classList.add("hidden");
        $("app").classList.remove("hidden");
        loadDashboard();
    } catch {
        adminToken = null;
        sessionStorage.removeItem("adminToken");
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  NAVIGATION
// ══════════════════════════════════════════════════════════════════════════════
const pageTitles = {
    dashboard: ["Dashboard", "ภาพรวมระบบ GameTopUp"],
    orders: ["Orders", "จัดการคำสั่งซื้อทั้งหมด"],
    users: ["Users", "รายชื่อผู้ใช้งาน"],
    games: ["Games", "รายการเกมและแพ็กเกจ"],
    api: ["API Docs", "คู่มือการใช้งาน API"],
};

function navigateTo(page) {
    document.querySelectorAll(".nav-item").forEach((n) => n.classList.remove("active"));
    document.querySelectorAll(".page").forEach((p) => p.classList.remove("active"));

    const navEl = document.querySelector(`.nav-item[data-page="${page}"]`);
    if (navEl) navEl.classList.add("active");
    const pageEl = $("page-" + page);
    if (pageEl) pageEl.classList.add("active");

    const [title, sub] = pageTitles[page] || [page, ""];
    $("page-title").textContent = title;
    $("page-subtitle").textContent = sub;

    if (page === "dashboard") loadDashboard();
    else if (page === "orders") loadOrders();
    else if (page === "users") loadUsers();
    else if (page === "games") loadGames();
    else if (page === "api") renderApiDocs();
}

document.querySelectorAll(".nav-item").forEach((nav) => {
    nav.addEventListener("click", (e) => {
        e.preventDefault();
        navigateTo(nav.dataset.page);
    });
});

document.querySelectorAll(".btn-text[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => navigateTo(btn.dataset.page));
});

$("refresh-btn").addEventListener("click", () => {
    const active = document.querySelector(".nav-item.active")?.dataset.page || "dashboard";
    navigateTo(active);
    showToast("รีเฟรชข้อมูลแล้ว");
});

// ══════════════════════════════════════════════════════════════════════════════
//  DASHBOARD
// ══════════════════════════════════════════════════════════════════════════════
async function loadDashboard() {
    try {
        const [statsRes, ordersRes] = await Promise.all([
            apiFetch("/admin/stats"),
            apiFetch("/admin/orders?limit=5"),
        ]);
        const s = statsRes.data;

        $("stat-users").textContent = s.totalUsers.toLocaleString();
        $("stat-orders").textContent = s.totalOrders.toLocaleString();
        $("stat-revenue").textContent = "฿" + s.totalRevenue.toLocaleString();
        $("stat-pending").textContent = s.ordersByStatus.pending.toLocaleString();

        renderRecentOrders(ordersRes.data);
        renderStatusChart(s.ordersByStatus, s.totalOrders);
    } catch (ex) {
        showToast(ex.message, "error");
    }
}

function renderRecentOrders(orders) {
    const el = $("recent-orders-list");
    if (!orders.length) {
        el.innerHTML = `<p style="color:var(--muted);text-align:center;padding:20px">ยังไม่มี Orders</p>`;
        return;
    }
    el.innerHTML = orders.map((o) => `
    <div class="recent-item">
      <div>
        <p class="recent-game">${o.gameName} — ${o.packageName}</p>
        <p class="recent-meta">${o.userEmail} · ${formatDate(o.createdAt)}</p>
      </div>
      <div style="text-align:right">
        <p class="recent-price">฿${o.packagePrice}</p>
        <div style="margin-top:4px">${statusBadge(o.status)}</div>
      </div>
    </div>
  `).join("");
}

function renderStatusChart(byStatus, total) {
    const items = [
        { key: "pending", label: "Pending", cls: "pending" },
        { key: "processing", label: "Processing", cls: "processing" },
        { key: "completed", label: "Completed", cls: "completed" },
        { key: "failed", label: "Failed", cls: "failed" },
    ];
    const el = $("status-chart");
    if (total === 0) {
        el.innerHTML = `<p style="color:var(--muted);text-align:center;padding:20px">ยังไม่มีข้อมูล</p>`;
        return;
    }
    el.innerHTML = items.map((i) => {
        const count = byStatus[i.key] || 0;
        const pct = total ? Math.round((count / total) * 100) : 0;
        return `
      <div class="chart-item">
        <div class="chart-label">
          <span>${i.label}</span>
          <span style="color:var(--muted)">${count} (${pct}%)</span>
        </div>
        <div class="chart-bar">
          <div class="chart-fill ${i.cls}" style="width:${pct}%"></div>
        </div>
      </div>
    `;
    }).join("");
}

// ══════════════════════════════════════════════════════════════════════════════
//  ORDERS PAGE
// ══════════════════════════════════════════════════════════════════════════════
async function loadOrders() {
    try {
        const res = await apiFetch("/admin/orders?limit=500");
        allOrders = res.data;
        renderOrdersTable(allOrders);
    } catch (ex) {
        showToast(ex.message, "error");
    }
}

function renderOrdersTable(orders) {
    const tbody = $("orders-tbody");
    if (!orders.length) {
        tbody.innerHTML = `<tr><td colspan="10" class="empty-row">ไม่พบ Orders</td></tr>`;
        return;
    }
    tbody.innerHTML = orders.map((o) => `
    <tr>
      <td><code style="font-size:11px;color:var(--muted)">${o.id.slice(0, 8)}…</code></td>
      <td>${o.userEmail}</td>
      <td style="font-weight:500">${o.gameName}</td>
      <td>${o.packageName}</td>
      <td><code>${o.playerId}</code></td>
      <td style="color:var(--accent2);font-weight:600">฿${o.packagePrice}</td>
      <td>${o.paymentMethod}</td>
      <td>${statusBadge(o.status)}</td>
      <td style="color:var(--muted);white-space:nowrap">${formatDate(o.createdAt)}</td>
      <td>
        <button class="btn-xs" onclick="openModal('${o.id}','${o.status}')">แก้ Status</button>
      </td>
    </tr>
  `).join("");
}

// Filter orders
function filterOrders() {
    const statusFilter = $("order-filter-status").value;
    const search = $("order-search").value.toLowerCase();
    let result = allOrders;
    if (statusFilter) result = result.filter((o) => o.status === statusFilter);
    if (search) result = result.filter((o) =>
        o.id.toLowerCase().includes(search) ||
        o.gameName.toLowerCase().includes(search) ||
        o.userEmail.toLowerCase().includes(search) ||
        o.playerId.toLowerCase().includes(search)
    );
    renderOrdersTable(result);
}

$("order-filter-status").addEventListener("change", filterOrders);
$("order-search").addEventListener("input", filterOrders);

// ══════════════════════════════════════════════════════════════════════════════
//  USERS PAGE
// ══════════════════════════════════════════════════════════════════════════════
async function loadUsers() {
    try {
        const res = await apiFetch("/admin/users");
        allUsers = res.data;
        renderUsersTable(allUsers);
    } catch (ex) {
        showToast(ex.message, "error");
    }
}

function renderUsersTable(users) {
    const tbody = $("users-tbody");
    if (!users.length) {
        tbody.innerHTML = `<tr><td colspan="5" class="empty-row">ยังไม่มีผู้ใช้</td></tr>`;
        return;
    }
    tbody.innerHTML = users.map((u, i) => `
    <tr>
      <td style="color:var(--muted)">${i + 1}</td>
      <td style="font-weight:500">${u.username}</td>
      <td>${u.email}</td>
      <td style="color:var(--muted)">${formatDate(u.createdAt)}</td>
      <td>
        <span class="badge ${u.orderCount > 0 ? "completed" : "pending"}">
          ${u.orderCount} orders
        </span>
      </td>
    </tr>
  `).join("");
}

$("user-search").addEventListener("input", (e) => {
    const q = e.target.value.toLowerCase();
    renderUsersTable(q
        ? allUsers.filter((u) => u.username.toLowerCase().includes(q) || u.email.toLowerCase().includes(q))
        : allUsers
    );
});

// ══════════════════════════════════════════════════════════════════════════════
//  GAMES PAGE
// ══════════════════════════════════════════════════════════════════════════════
async function loadGames() {
    try {
        const res = await fetch(API + "/games");
        const list = await res.json();
        const grid = $("games-grid");
        grid.innerHTML = "";

        // ดึงรายละเอียดแต่ละเกมพร้อมกัน
        const details = await Promise.all(
            list.data.map((g) => fetch(API + "/games/" + g.slug).then((r) => r.json()))
        );

        grid.innerHTML = details.map((d) => {
            const g = d.data;
            return `
        <div class="game-card">
          <img src="${g.image}" alt="${g.name}" loading="lazy" onerror="this.style.background='var(--surface)'" />
          <div class="game-card-body">
            <span class="game-cat">${g.category}</span>
            <p class="game-name">${g.name}</p>
            <p class="game-desc">${g.description}</p>
            <p class="game-pkgs">📦 ${g.packages.length} แพ็กเกจ</p>
            <div class="game-prices">
              ${g.packages.map((p) => `<span class="price-tag">฿${p.price}</span>`).join("")}
            </div>
          </div>
        </div>
      `;
        }).join("");
    } catch (ex) {
        showToast(ex.message, "error");
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  API DOCS PAGE
// ══════════════════════════════════════════════════════════════════════════════
function renderApiDocs() {
    const groups = [
        {
            title: "Auth — /api/auth",
            endpoints: [
                { method: "POST", path: "/api/auth/register", desc: "สมัครสมาชิก", auth: false },
                { method: "POST", path: "/api/auth/login", desc: "เข้าสู่ระบบ รับ JWT Token", auth: false },
                { method: "GET", path: "/api/auth/me", desc: "ดูข้อมูลผู้ใช้งานตัวเอง", auth: true },
            ],
        },
        {
            title: "Games — /api/games",
            endpoints: [
                { method: "GET", path: "/api/games", desc: "รายการเกมทั้งหมด", auth: false },
                { method: "GET", path: "/api/games/:slug", desc: "รายละเอียดเกม + แพ็กเกจ", auth: false },
            ],
        },
        {
            title: "Orders — /api/orders",
            endpoints: [
                { method: "POST", path: "/api/orders", desc: "สร้าง Order ใหม่ (Rate limit: 20/10min)", auth: true },
                { method: "GET", path: "/api/orders/my", desc: "ประวัติ Order ของตัวเอง", auth: true },
                { method: "GET", path: "/api/orders/:id", desc: "รายละเอียด Order เฉพาะ (เจ้าของเท่านั้น)", auth: true },
            ],
        },
        {
            title: "Admin — /api/admin 🔒",
            endpoints: [
                { method: "POST", path: "/api/admin/login", desc: "Admin Login (Rate limit: 5/30min)", auth: false },
                { method: "GET", path: "/api/admin/verify", desc: "ตรวจสอบ Admin Token", auth: true, admin: true },
                { method: "GET", path: "/api/admin/stats", desc: "สถิติภาพรวมระบบ", auth: true, admin: true },
                { method: "GET", path: "/api/admin/users", desc: "รายชื่อ Users ทั้งหมด", auth: true, admin: true },
                { method: "GET", path: "/api/admin/orders", desc: "Orders ทั้งหมด (query: status, limit, offset)", auth: true, admin: true },
                { method: "PATCH", path: "/api/admin/orders/:id/status", desc: "อัปเดต Status Order", auth: true, admin: true },
            ],
        },
    ];

    $("api-endpoints").innerHTML = groups.map((g) => `
    <div class="endpoint-group">
      <div class="endpoint-group-title">${g.title}</div>
      ${g.endpoints.map((ep) => `
        <div class="endpoint-row">
          <div>
            <span class="method ${ep.method}">${ep.method}</span>
          </div>
          <div>
            <div class="endpoint-path">${ep.path}</div>
            <div class="endpoint-desc">${ep.desc}</div>
            ${ep.auth ? `<span class="auth-badge">${ep.admin ? "🔐 Admin JWT" : "🔑 Bearer JWT"}</span>` : ""}
          </div>
        </div>
      `).join("")}
    </div>
  `).join("");
}

// ══════════════════════════════════════════════════════════════════════════════
//  UPDATE STATUS MODAL
// ══════════════════════════════════════════════════════════════════════════════
let selectedOrderId = null;

function openModal(id, currentStatus) {
    selectedOrderId = id;
    $("modal-order-id").textContent = "Order ID: " + id;
    $("modal-status").value = currentStatus;
    $("modal").classList.remove("hidden");
}

$("modal-cancel").addEventListener("click", () => $("modal").classList.add("hidden"));
$("modal").addEventListener("click", (e) => {
    if (e.target === $("modal")) $("modal").classList.add("hidden");
});

$("modal-confirm").addEventListener("click", async () => {
    const status = $("modal-status").value;
    try {
        await apiFetch(`/admin/orders/${selectedOrderId}/status`, {
            method: "PATCH",
            body: JSON.stringify({ status }),
        });
        showToast(`อัปเดต Status เป็น "${status}" สำเร็จ`);
        $("modal").classList.add("hidden");
        loadOrders();
        loadDashboard();
    } catch (ex) {
        showToast(ex.message, "error");
    }
});

// ══════════════════════════════════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════════════════════════════════
tryAutoLogin();
