const axios = require("axios");

const PEAMSUB_API_BASE_URL = "https://api.peamsub24hr.com";
const PEAMSUB_API_KEY = process.env.PEAMSUB_API_KEY;

/**
 * Proxy Request to Peamsub API
 */
async function peamsubRequest(endpoint, method = "GET", body = null) {
    try {
        const config = {
            method: method.toUpperCase(),
            url: `${PEAMSUB_API_BASE_URL}${endpoint}`,
            headers: {
                "x-api-key": PEAMSUB_API_KEY,
                "Content-Type": "application/json",
            },
        };

        if (body) {
            config.data = body;
            // Peamsub บางครั้งต้องการ x-api-key ใน body
            if (typeof body === 'object' && !Array.isArray(body)) {
                config.data = { ...body, "x-api-key": PEAMSUB_API_KEY };
            }
        }

        const response = await axios(config);
        return {
            statusCode: response.status,
            data: response.data,
        };
    } catch (error) {
        const statusCode = error.response?.status || 500;
        const errorData = error.response?.data || { message: error.message };
        console.error(`❌ Peamsub API Error [${endpoint}]:`, errorData);
        return {
            statusCode,
            data: errorData,
        };
    }
}

/**
 * Proxy Request to IndexGame API (via Peamsub)
 */
async function indexGameRequest(endpoint, method = "GET", body = null) {
    // IndexGame usually uses peamsub as a middleman or directly. 
    // Based on Baimonshop code, it seems they have a specific endpoint or logic.
    // We'll use the same proxy logic for now.
    return peamsubRequest(endpoint, method, body);
}

module.exports = {
    peamsubRequest,
    indexGameRequest,
};
