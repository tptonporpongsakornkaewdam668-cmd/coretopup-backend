require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const hpp = require("hpp");
const path = require("path");

const { apiLimiter } = require("./middleware/rateLimiter");
const authRoutes = require("./routes/auth");
const gamesRoutes = require("./routes/games");
const ordersRoutes = require("./routes/orders");
const adminRoutes = require("./routes/admin");
const peamsubRoutes = require("./routes/peamsub");
const paymentRoutes = require("./routes/payment");
const historyRoutes = require("./routes/history");




// ─── ตรวจสอบ ENV ที่จำเป็น ─────────────────────────────────────────────────────
const REQUIRED_ENV = ["JWT_SECRET", "ADMIN_JWT_SECRET", "ADMIN_EMAIL", "ADMIN_PASSWORD_HASH"];
const missingEnv = REQUIRED_ENV.filter((key) => !process.env[key]);
if (missingEnv.length > 0) {
  console.error(`\n❌ Missing ENV variables: ${missingEnv.join(", ")}`);
  console.error("กรุณาตั้งค่าใน .env ก่อนรัน server\n");
  process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 5000;

// ──────────────────────────────────────────────────────────────────────────────
//  SECURITY MIDDLEWARE
// ──────────────────────────────────────────────────────────────────────────────

// 1. Helmet — ตั้งค่า HTTP Security Headers
//    ป้องกัน: XSS, Clickjacking, MIME sniffing, HSTS, etc.
app.use(
  helmet({
    contentSecurityPolicy: false, // ปิดเพราะ admin panel มี inline script
    crossOriginEmbedderPolicy: false,
  })
);
// 2. CORS — อนุญาตพอร์ตที่กำหนดใน .env + พอร์ตทั่วไปที่พบบ่อยในเครื่องตัวเอง
const devOrigins = ["http://localhost:5173", "http://localhost:3000", "http://localhost:5000", "http://localhost:8080"];
const envOrigins = (process.env.ALLOWED_ORIGINS || "").split(",").map(o => o.trim()).filter(o => o.length > 0);
const allowedOrigins = Array.from(new Set([...devOrigins, ...envOrigins]));

console.log("✅ Allowed Origins for CORS:", allowedOrigins);

app.use(
  cors({
    origin: (origin, callback) => {
      // 1. ถ้าไม่มี origin (เช่น Postman)
      // 2. ถ้าเป็น localhost/127.0.0.1 (สำหรับ development)
      // 3. ถ้าอยู่ใน ALLOWED_ORIGINS
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        console.warn(`⚠️ CORS Blocked: Origin [${origin}] is not in allowed list`);
        callback(null, false); // ส่งเท็จแทน error เพื่อลดปัญหาระบบล่ม
      }
    },


    credentials: true,
    methods: ["GET", "POST", "PATCH", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

// 3. Body Parser — จำกัดขนาด body ป้องกัน payload flooding
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: true, limit: "10kb" }));

// 4. HPP — ป้องกัน HTTP Parameter Pollution
app.use(hpp());

// 5. Global Rate Limit — ทุก API
app.use("/api", apiLimiter);

// 6. ซ่อน Express signature เพื่อไม่ให้แฮกเกอร์รู้ stack
app.disable("x-powered-by");

// ──────────────────────────────────────────────────────────────────────────────
//  STATIC FILES — Admin Panel
// ──────────────────────────────────────────────────────────────────────────────
app.use(
  "/admin",
  express.static(path.join(__dirname, "public", "admin"), {
    index: "index.html",
    etag: true,
    lastModified: true,
  })
);

// Fallback: ออก /admin/anything กลับ index.html
app.get("/admin/*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin", "index.html"));
});

// ──────────────────────────────────────────────────────────────────────────────
//  API ROUTES
// ──────────────────────────────────────────────────────────────────────────────
app.use("/api/auth", authRoutes);
app.use("/api/games", gamesRoutes);
app.use("/api/orders", ordersRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/peamsub", peamsubRoutes);
app.use("/api/payment", paymentRoutes);
app.use("/api/history", historyRoutes);




// ─── Health Check ─────────────────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({
    message: "🎮 GameTopUp API is running!",
    version: "1.0.0",
    admin: "http://localhost:" + PORT + "/admin",
  });
});

// ─── 404 Handler ──────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: "Route not found" });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  // ซ่อน error details ใน production
  if (process.env.NODE_ENV === "production") {
    console.error("Server Error:", err.message);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
  console.error(err.stack);
  res.status(500).json({ success: false, message: err.message });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 GameTopUp Backend running on http://localhost:${PORT}`);
  console.log(`🛡️  Security: Helmet + CORS + RateLimit + HPP + Validation`);
  console.log(`🖥️  Admin Panel: http://localhost:${PORT}/admin`);
  console.log(`📋 Environment: ${process.env.NODE_ENV}\n`);
});
